/**
 * @author Joan Pinto, 6349864
 * Title: County Vaccinations
 * Semester:                COP 2210, Fall 2023
 * Professor's Name         Prof.Charters
 * Description of Program's Functionality:
 * This program asks the user for their name, date of birth, when they took their first, second and booster vaccines,
 * who was the manufacturer and where did they get it .
 */

import java.util.Scanner;

public class CountyVaccinations {
    public static  Scanner keyboard=new Scanner(System.in);
    public static void main(String[] args) {

        CoronaVaccineRecord aVaccineCard1=createAVaccineRecord();
        Patient aPatient1=createcreateAPatient(aVaccineCard1);
        reportVaccinations(aPatient1);

        CoronaVaccineRecord aVaccineCard2=createAVaccineRecord();
        Patient aPatient2=createcreateAPatient(aVaccineCard2);
        reportVaccinations(aPatient2);

        CoronaVaccineRecord aVaccineCard3=createAVaccineRecord();
        Patient aPatient3=createcreateAPatient(aVaccineCard3);
        reportVaccinations(aPatient3);

    }

    /**
     * Ask's the user all the information about the vaccine
     * @return returns the patients vaccination info
     */
    public static CoronaVaccineRecord createAVaccineRecord()
    {
        String nameOfVaccineManufacturer, dateOfFirstShot, dateOfSecondShot, dateOfBoosterShot, vaccinationSite;

        System.out.println("What is the name of the Corona Vaccine Manufacturer?");

        nameOfVaccineManufacturer=keyboard.nextLine();

        System.out.println("What is the date of your first Corona vaccine shot? mm/dd/yyyy");

        dateOfFirstShot= keyboard.nextLine();

        System.out.println("What is the date of your second Corona vaccine shot? mm/dd/yyyy");

        dateOfSecondShot= keyboard.nextLine();

        System.out.println("What is the date of your booster shot?");

        dateOfBoosterShot= keyboard.nextLine();

        System.out.println("What is the location/site of your vaccines? (CVS, Walgreens, etc.)");

        vaccinationSite= keyboard.nextLine();

        CoronaVaccineRecord vaccineRecord=new CoronaVaccineRecord(nameOfVaccineManufacturer,dateOfFirstShot, dateOfSecondShot,
                dateOfBoosterShot, vaccinationSite);

        return vaccineRecord;
    }

    /**
     * Ask's the user for their personal information like their name and date of birth.
     * @param record gives their vaccination information as a parameter
     * @return returns the complete patient info
     */
    public static Patient createcreateAPatient(CoronaVaccineRecord record)
    {
         String firstName, lastName, dob;

        System.out.println("What is the patient's first name?");

        firstName= keyboard.nextLine();

        System.out.println("What is the patient's last name?");

        lastName= keyboard.nextLine();

        System.out.println("What is the patient's date of birth? (mm/dd/yyyy)");

        dob= keyboard.nextLine();

        Patient patient=new Patient(firstName, lastName, dob, record);
        return patient;
    }

    /**
     * Prints the patients information cared
     * @param aPatient gives the patients information and vaccination information together as a single parameter
     */
    public static void reportVaccinations(Patient aPatient)
    {
        System.out.println("Here is the vaccination record for "+aPatient);
    }
}
