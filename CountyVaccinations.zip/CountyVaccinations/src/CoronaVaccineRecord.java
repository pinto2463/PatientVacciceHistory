public class CoronaVaccineRecord {
    private String nameOfVaccineManufacturer;
    private String dateOfFirstShot;
    private String dateOfSecondShot;
    private String dateOfBoosterShot;
    private String vaccinationSite;

    public CoronaVaccineRecord(String nameOfVaccineManufacturer,  String dateOfFirstShot, String dateOfSecondShot,
                               String dateOfBoosterShot, String vaccinationSite)
    {
        this.nameOfVaccineManufacturer=nameOfVaccineManufacturer;
        this.dateOfFirstShot=dateOfFirstShot;
        this.dateOfSecondShot=dateOfSecondShot;
        this.dateOfBoosterShot=dateOfBoosterShot;
        this.vaccinationSite=vaccinationSite;
    }

    public String getNameOfVaccineManufacturer()
    {
        return nameOfVaccineManufacturer;
    }

    public void setNameOfVaccineManufacturer(String nameOfVaccineManufacturer)
    {
        this.nameOfVaccineManufacturer=nameOfVaccineManufacturer;
    }

    public  String getDateOfFirstShot()
    {
        return  dateOfFirstShot;
    }

    public void setDateOfFirstShot(String dateOfFirstShot)
    {
        this.dateOfFirstShot=dateOfFirstShot;
    }

    public String getDateOfSecondShot()
    {
        return dateOfSecondShot;
    }

    public void setDateOfSecondShot(String dateOfSecondShot)
    {
        this.dateOfSecondShot=dateOfSecondShot;
    }

    public String getDateOfBoosterShot()
    {
        return dateOfBoosterShot;
    }

    public void setDateOfBoosterShot(String dateOfBoosterShot)
    {
        this.dateOfBoosterShot=dateOfBoosterShot;
    }

    public String getVaccinationSite()
    {
        return vaccinationSite;
    }

    public void setVaccinationSite(String vaccinationSite)
    {
        this.vaccinationSite=vaccinationSite;
    }

    public String toString()
    {
        return"Name of manufacturer: "+ nameOfVaccineManufacturer+"\n"+
                "Date of first shot: "+dateOfFirstShot+"\n"+
                "Date of second shot: " +dateOfSecondShot+"\n"+
                "Date of booster shot: "+dateOfBoosterShot+"\n"+
                "Vaccination site: "+vaccinationSite+"\n\n";
    }






}
