public class Patient {
    private String firstName;
    private String lastName;
    private String dob;
    private CoronaVaccineRecord vaccineRecord;


    public Patient(String firstName, String lastName, String dob, CoronaVaccineRecord vaccineRecord)
    {
        this.firstName=firstName;
        this.lastName=lastName;
        this.dob=dob;
        this.vaccineRecord=vaccineRecord;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName=firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName=lastName;
    }

    public String getDob()
    {
        return dob;
    }

    public void setDob(String dob)
    {
        this.dob=dob;
    }

    public CoronaVaccineRecord getVaccineRecord()
    {
        return vaccineRecord;
    }

    public void setVaccineRecord(CoronaVaccineRecord vaccineRecord)
    {
        this.vaccineRecord=vaccineRecord;
    }

    public String toString()
    {
        return firstName+" "+lastName+"\n\n"+
                "Patient "+firstName+" "+lastName+
                ", date of birth: "+dob+"\n\n"+
                "Vaccine record: "+"\n"+vaccineRecord;
    }




}
